Library Project including Leanback framework support.
